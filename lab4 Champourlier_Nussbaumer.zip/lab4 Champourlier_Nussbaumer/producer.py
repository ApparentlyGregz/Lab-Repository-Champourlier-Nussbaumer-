# %%
import socket
from pathlib import Path
from confluent_kafka import Producer

# %%
conf = {'bootstrap.servers': 'localhost:9092',
        'client.id': socket.gethostname()}

producer = Producer(conf)

# %%
topic='book-lines'
book_path = Path(__file__).parent / 'texte.txt'

# %% Streaming Query
with book_path.open('r', encoding='utf-8') as book:
  for line in book:
    message = line.rstrip('\r\n')
    producer.produce(
      topic=topic,
      value=message
    )
    print(message)
    producer.poll(0)

producer.flush()
# %%
