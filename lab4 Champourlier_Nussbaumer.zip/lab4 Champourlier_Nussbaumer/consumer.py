# %%
import re
from pathlib import Path
from confluent_kafka import Consumer

# %%
conf = {'bootstrap.servers': 'localhost:9092',
        'group.id': 'book-reader',
        'auto.offset.reset': 'smallest'}

consumer = Consumer(conf)

# %%
topic='book-lines'
consumer.subscribe([topic])
output_path = Path(__file__).parent / 'texte_nettoye.txt'

# %%
# Configuration
MAX_EMPTY_POLLS = 10  # Ends after ~10 seconds of silence
MAX_ERRORS = 5        # Ends after 5 consecutive errors
empty_polls = 0
error_count = 0

try:
    # Le mode 'a' ajoute les nouvelles lignes sans effacer le fichier existant.
    with output_path.open('a', encoding='utf-8') as output:
        while True:
            msg = consumer.poll(1.0)

            # 1. Handle "No Message" (Timeout)
            if msg is None:
                empty_polls += 1
                if empty_polls >= MAX_EMPTY_POLLS:
                    print("Closing: No new messages received.")
                    break
                continue

            # 2. Handle Errors
            if msg.error():
                error_count += 1
                print(f"Consumer error: {msg.error()}")
                if error_count >= MAX_ERRORS:
                    print("Closing: Too many consecutive errors.")
                    break
                continue

            # 3. Handle Success
            empty_polls = 0
            error_count = 0

            message = msg.value().decode('utf-8')
            message = message.lower()
            message = re.sub(r'[^\w\s]|_', ' ', message)
            words = message.split()
            cleaned_message = ' '.join(words)

            # Ignore les lignes vides apres nettoyage.
            if cleaned_message:
                output.write(cleaned_message + '\n')
                output.flush()
                print(f"Rcvd message: {cleaned_message}")
finally:
    # Clean up, meme en cas d'arret avec Ctrl+C.
    consumer.close()
