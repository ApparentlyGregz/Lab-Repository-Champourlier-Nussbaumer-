# TP 4 — Traitement de texte avec Kafka
Membres du groupe

- Grégoire CHAMPOURLIER - Git : ApparentlyGregz
- Hippolyte NUSSBAUMER -  Git : hippolyte-coder
- Groupe 3

 Objective

Send a book line by line in Kafka, see the texte and then clean the text and save it in a new file

```text
texte.txt → producer.py → topic book-lines → consumer.py → texte_nettoye.txt
```

Book that we used

- Titre : The Art of War
- Auteur : Antoine Henri Jomini (baron de Jomini)
- Langue : anglais
- Source : [Project Gutenberg, livre n° 13549](https://www.gutenberg.org/ebooks/13549)
- Fichier local : `texte.txt`

